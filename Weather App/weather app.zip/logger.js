const bunyan = require('bunyan');

module.exports = {
    createLogger: function(recordType, operation) {
        var log = bunyan.createLogger({
            name: recordType + ' ' + operation,
            streams: [{
                    level: 'info',
                    stream: process.stdout // log INFO and above to stdout 
                },
                {
                    level: 'error',
                    type: 'file',
                    path: './log/foo.log' // log ERROR and above to a file 
                }
            ]
        });

        return log;
    },
}